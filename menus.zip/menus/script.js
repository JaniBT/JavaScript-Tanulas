function navBar() {
    const y = document.querySelector("nav");
    y.classList.toggle("closed");

    const isClosed = y.classList.contains('closed');
    localStorage.setItem('navbarClosed', isClosed.toString());
}

const isNavbarClosed = localStorage.getItem('navbarClosed');

if (isNavbarClosed === 'true') {
    document.querySelector('nav').classList.add('closed');
} else if (isNavbarClosed === 'false') {
    document.querySelector('nav').classList.remove('closed');
}